---
name: Magic Pro DAW
colors:
  surface: '#131313'
  surface-dim: '#131313'
  surface-bright: '#393939'
  surface-container-lowest: '#0e0e0e'
  surface-container-low: '#1c1b1b'
  surface-container: '#20201f'
  surface-container-high: '#2a2a2a'
  surface-container-highest: '#353535'
  on-surface: '#e5e2e1'
  on-surface-variant: '#c7c4d8'
  inverse-surface: '#e5e2e1'
  inverse-on-surface: '#313030'
  outline: '#918fa1'
  outline-variant: '#464555'
  surface-tint: '#c3c0ff'
  primary: '#c3c0ff'
  on-primary: '#1d00a5'
  primary-container: '#4f46e5'
  on-primary-container: '#dad7ff'
  inverse-primary: '#4d44e3'
  secondary: '#89ceff'
  on-secondary: '#00344d'
  secondary-container: '#00a2e6'
  on-secondary-container: '#00344e'
  tertiary: '#ffb695'
  on-tertiary: '#571f00'
  tertiary-container: '#a44100'
  on-tertiary-container: '#ffd2be'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#e2dfff'
  primary-fixed-dim: '#c3c0ff'
  on-primary-fixed: '#0f0069'
  on-primary-fixed-variant: '#3323cc'
  secondary-fixed: '#c9e6ff'
  secondary-fixed-dim: '#89ceff'
  on-secondary-fixed: '#001e2f'
  on-secondary-fixed-variant: '#004c6e'
  tertiary-fixed: '#ffdbcc'
  tertiary-fixed-dim: '#ffb695'
  on-tertiary-fixed: '#351000'
  on-tertiary-fixed-variant: '#7b2f00'
  background: '#131313'
  on-background: '#e5e2e1'
  surface-variant: '#353535'
typography:
  display-sm:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.02em
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-xs:
    fontFamily: JetBrains Mono
    fontSize: 10px
    fontWeight: '500'
    lineHeight: 12px
    letterSpacing: 0.05em
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
  toolbar-button:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 16px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  grid-unit: 4px
  toolbar-height: 40px
  inspector-width: 260px
  gutter: 1px
  margin-sm: 8px
  margin-md: 16px
---

## Brand & Style

The design system is engineered for professional music production, prioritizing high-density information visualization and sustained focus during long creative sessions. The brand personality is technical, precise, and sophisticated, catering to power users who require immediate access to complex MIDI data.

The design style is a hybrid of **Minimalism** and **Modern Corporate**, utilizing a "Pro Dark" aesthetic. It emphasizes a structured environment where the interface recedes to let the musical data (MIDI notes, waveforms, and automation) take center stage. Visual hierarchy is established through luminance and color intensity rather than physical depth, ensuring the UI feels like a high-performance instrument.

## Colors

The palette is anchored in a Deep Charcoal (`#1A1A1A`) to reduce eye strain. The primary functional color is a vibrant Indigo, used for active MIDI notes and selection states. An Electric Blue secondary color is reserved for secondary tools or ghost notes.

A specialized "Note-Brightness" logic is applied to the primary Indigo: velocity values (0-127) map to the luminance of the note color, where higher velocity results in a brighter, more saturated Indigo. The Playhead is a high-contrast 2px line using a distinct rose-red to ensure visibility across dense arrangements. Piano keys utilize a stark, high-contrast black and white logic to mimic physical hardware.

## Typography

The typography system uses **Inter** for all functional UI elements due to its exceptional legibility at small sizes. For technical data—such as timecode, BPM, and MIDI coordinate values—**JetBrains Mono** is utilized to provide a clear, monospaced distinction between labels and dynamic values.

Information density is prioritized; therefore, the scale is compact. Labels on the piano roll and inspector panels should rarely exceed 13px. All caps are used sparingly for section headers in the inspector to maintain a professional, organized structure.

## Layout & Spacing

This design system employs a **Fixed Grid** model optimized for high-density desktop use. The layout is divided into three primary zones: the Top Toolbar, the Left Inspector/Library, and the Central Piano Roll.

The spacing rhythm is based on a 4px baseline grid. The Piano Roll background uses 1px gutters for grid lines (quantization visualizers) to maximize the "workspace" for MIDI notes. Margins are kept to a minimum (8px) to maximize the screen real estate dedicated to the timeline. On smaller viewports, the Inspector collapses to an icon-only sidebar rather than reflowing, preserving the horizontal integrity of the musical timeline.

## Elevation & Depth

Visual hierarchy is achieved through **Tonal Layers** and subtle **Glassmorphism**. 

1. **Base Layer:** The darkest tone (`#0F0F0F`) is used for the main workspace background.
2. **Surface Layer:** Toolbars and Sidebars use a slightly lighter Charcoal (`#1E1E1E`).
3. **Glassmorphism:** The Top Toolbar and floating MIDI tool palettes use a 20px backdrop blur with a 10% white overlay to create a sense of floating over the data without obstructing it.
4. **Outlines:** Instead of shadows, 1px solid borders (`#333333`) are used to separate UI panels, ensuring the interface remains crisp and "un-fuzzy."

## Shapes

The design system uses a **Soft** shape language. MIDI notes are rendered as rectangles with a 4px corner radius (`0.25rem`), providing a modern feel that still aligns perfectly with the underlying quantization grid. 

Buttons in the toolbar use the same 4px radius, while input fields and dropdowns in the inspector remain sharp or minimally rounded to maintain a technical, "rack-mount" hardware aesthetic.

## Components

- **MIDI Notes:** Rounded rectangles. Fill color is Indigo. Border is 1px inside, 20% lighter than the fill. Height is determined by the pitch; width by duration.
- **Buttons:** Low-profile. Default state is a dark grey stroke; active state switches to Indigo fill with white text. No gradients.
- **Toolbars:** 40px height, semi-transparent background blur. Icons are 16x16px with 1.5px stroke weight.
- **Inspector Fields:** Compact, 24px height. Text is aligned left; values are aligned right in JetBrains Mono.
- **Piano Keys:** White keys use a subtle vertical gradient (off-white to white); Black keys are flat black with a 1px top-highlight to simulate physical depth.
- **Playhead:** A strict 2px vertical line in Rose-Red, extending across all horizontal tracks with a circular handle at the top for scrubbing.
- **Velocity Sliders:** Vertical bars in the bottom dock, matching the color and brightness logic of the MIDI notes above them.